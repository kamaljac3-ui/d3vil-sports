# Launch Angle Edges

Daily scan that compares each hitter's attack angle, bat speed and launch angle against the
opposing starter's pitch mix (approach angle + velocity) and pushes the best matchups to ntfy.

## Setup
1. Copy `launch-angle/` and `.github/workflows/launch-angle-alerts.yml` into the repo.
2. Repo → Settings → Secrets and variables → Actions → add:
   - `NTFY_TOPIC` — the topic your ntfy app subscribes to (required)
   - `NTFY_SERVER` — only if self-hosted (default https://ntfy.sh)
   - `NTFY_TOKEN` — only if your topic needs an access token
3. Actions → Launch Angle Edges → Run workflow → mode `morning`, dry_run `1` to preview in the log.
   Then run again with dry_run `0` to get a real push.

## What you get
- **10 AM ET** — one push with the day's top edges using probable starters vs active rosters.
- **Every 30 min, 11 AM–10 PM ET** — when a game's lineups post, one push for that game
  listing only hitters in the lineup who clear the bar. Each game alerts once.

## Edge rule (change via env in the workflow)
- `MIN_EDGE` (0.03) — window % must beat the hitter's own baseline vs a league-average fastball by 3+ pts
- `GAP_LO` / `GAP_HI` (5 / 12) — attack angle 5–12° steeper than the starter's main pitch drops
- `TOP_N` (8) — max hitters in the morning push
- `FENCE` (380) — fence distance used for HR contact %

## Data
Savant leaderboards (bat tracking, swing path/attack angle, exit velo) refresh weekly; pitcher
pitch-by-pitch data refreshes daily; early in a season it falls back to last year.
If Savant ever blocks a download, drop leaderboard CSVs into `launch-angle/data/` and they're used automatically.
